package com.example.colorchooser;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity2 extends AppCompatActivity {

    ConstraintLayout layout2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        layout2 = findViewById(R.id.layout2);
        initSettings();
        initColorGroup();
    }

        private void initColorGroup () {
            RadioGroup cg = findViewById(R.id.ColorGroup);
            RadioButton red = findViewById(R.id.redButton);
            RadioButton blue = findViewById(R.id.blueButton);
            RadioButton green = findViewById(R.id.greenButton);
            cg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup radioGroup, int i) {
                    SharedPreferences sp = getSharedPreferences("ColorGroupPreferences", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sp.edit();
                    int colorSetting;
                    if (red.isChecked()) {
                        colorSetting = 0xFF000000;
                    } else if (blue.isChecked()) {
                        colorSetting = 0xFF0000FF;
                    } else if (green.isChecked()) {
                        colorSetting = 0xFF00FF00;
                    } else {
                        colorSetting = 0xFFFFFF00;
                    }
                    editor.putInt("sortcolor", colorSetting);
                    editor.apply();
                }

            });

        }
        private void initSettings() {
            SharedPreferences sharedPref = getSharedPreferences("ColorGroupPreferences", Context.MODE_PRIVATE);
            int colorGroup = sharedPref.getInt("sortcolor", 0xFFFF00FF);
            RadioButton red = findViewById(R.id.redButton);
            RadioButton blue = findViewById(R.id.blueButton);
            RadioButton green = findViewById(R.id.greenButton);
            RadioButton yellow = findViewById(R.id.yellowButton);
            switch (colorGroup){
                case 0xFF000000:
                    red.setChecked(true);
                    break;
                case 0xFF0000FF:
                    blue.setChecked(true);
                    break;
                case 0xFF00FF00:
                    green.setChecked(true);
                    break;
                default:
                    yellow.setChecked(true);
            }
    }


}