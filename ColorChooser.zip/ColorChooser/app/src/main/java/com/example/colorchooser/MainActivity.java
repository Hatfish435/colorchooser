package com.example.colorchooser;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    ConstraintLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initActivityChange();

        layout = findViewById(R.id.layout);

        int color = 0xFFFF00FF;
        layout.setBackgroundColor(color);


    }

    private void initActivityChange() {
        Button SurpriseButton= findViewById(R.id.ActivityChange);
        SurpriseButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

    }

    @Override
    public void onResume(){
        super.onResume();
        SharedPreferences sharedPref = getSharedPreferences("ColorGroupPreferences", Context.MODE_PRIVATE);
        int colorGroup = sharedPref.getInt("sortcolor", 0xFFFF00FF);
        layout.setBackgroundColor(colorGroup);
    }
}